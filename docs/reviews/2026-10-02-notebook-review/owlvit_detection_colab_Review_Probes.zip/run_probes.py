"""Row 60 probes: owlvit_detection_colab.ipynb at origin/main 48731001 (blob fff9ff98).

CPU only (CUDA_VISIBLE_DEVICES=-1, 4 threads). Env: conda eo-notebook-test (torch 2.13.0+cpu vs pin 2.14.0,
transformers 4.57.6, pillow 12.3.0 vs pin 11.3.0, numpy 2.5.3). Weights: the local clone's pre-staged
weights/owlvit-base-patch32 (verify_snapshot re-hashes all 8 files). The notebook's code cells are executed
from the .ipynb in one namespace; cell 3 runs with DIMER_NOTEBOOK_CI_PREINSTALLED=1 (no pip install) and cell 7
is replaced by verify_snapshot + from_pretrained on the local snapshot (no manifest write, no download).

Usage: python run_probes.py <worktree> <weights_dir> <out_json>
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
WT = Path(sys.argv[1])
WEIGHTS = Path(sys.argv[2])
OUT = Path(sys.argv[3])
NB = WT / "tutorials" / "owlvit_detection_colab.ipynb"
results: dict = {}


def save():
    OUT.write_text(json.dumps(results, indent=1, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
md_all = "\n".join(s for s, c in zip(src, cells, strict=True) if c["cell_type"] == "markdown")

# P0: identity, carried-module parity, generator --check
blob = subprocess.run(["git", "-C", str(WT), "rev-parse", "HEAD:tutorials/owlvit_detection_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
module = (WT / "src/owlvit_detection_pipeline/pipeline.py").read_text(encoding="utf-8")
carried = src[5]
mod_lines, car_lines = module.splitlines(), carried.splitlines()
diff = [(a, b) for a, b in zip(mod_lines, car_lines, strict=False) if a != b]
chk = subprocess.run([sys.executable, str(WT / "tools/build_notebook.py"), "--check"], cwd=WT,
                     capture_output=True, text=True)
results["P0"] = {
    "notebook_blob": blob, "recorded_blob_prefix": "fff9ff981ddc", "blob_matches_record": blob.startswith("fff9ff981ddc"),
    "n_cells": len(cells), "n_code": len(code_idx), "outputs_saved": sum(len(c.get("outputs", [])) for c in cells),
    "metadata_dimer": nb["metadata"]["dimer"],
    "carried_vs_module_line_count": [len(mod_lines), len(car_lines)], "differing_lines": diff,
    "build_notebook_check_rc": chk.returncode, "build_notebook_check_out": (chk.stdout + chk.stderr)[-400:],
}
save()

# P1: static text checks
results["P1"] = {
    "stale_no_run_recorded": "No run with the pinned weights has been recorded" in md_all,
    "stale_runtimes_not_measured": "Runtimes are not measured in this revision" in md_all,
    "declares_spec": nb["metadata"]["dimer"]["notebook_spec"],
    "has_how_to_use": "how to use this notebook" in md_all.lower(),
    "has_infrastructure_label": "infrastructure" in md_all.lower(),
    "has_troubleshooting": "troubleshoot" in md_all.lower(),
    "has_predict_prompt": bool(re.search(r"\bpredict\b", md_all, re.I)),
    "has_what_to_notice_or_expected": bool(re.search(r"what to notice|expected result", md_all, re.I)),
    "look_for_notes": len(re.findall(r"Look for", md_all)),
    "google_colab_import_in_byod": "from google.colab import files" in src[9],
    "source_getattr_fallback": "getattr(pipe, 'source', 'local-snapshot')" in src[7],
    "torchaudio_pin": [p for p in re.findall(r"'([^']+==[^']+)'", src[3]) if p.startswith("torchaudio")],
    "restart_text_in_cell3_md": "restart instruction" in src[2],
    "run_all_claims_no_intervention": "no configuration edit" in src[0],
    "threshold_param_cell": [i for i in code_idx if "threshold = 0.1  # @param" in src[i]],
    "rerun_instruction_for_experiments": "re-run from" in src[18].lower() or "rerun from" in src[18].lower(),
}
save()

# Shared namespace executing the notebook's own cells
import torch  # noqa: E402

torch.set_num_threads(4)
work = Path(tempfile.mkdtemp(prefix="r60_"))
os.chdir(work)
ns: dict = {}


def run_cell(i, overrides=None):
    code = src[i]
    for k, v in (overrides or {}).items():
        code = re.sub(rf"^{k} = .*$", lambda _m, k=k, v=v: f"{k} = {v!r}", code, count=1, flags=re.M)
    buf = io.StringIO()
    t0 = time.time()
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(code, f"cell{i}", "exec"), ns)
        return {"ok": True, "s": round(time.time() - t0, 2), "stdout_tail": buf.getvalue()[-600:]}
    except BaseException as exc:  # noqa: BLE001
        return {"ok": False, "s": round(time.time() - t0, 2), "error": f"{type(exc).__name__}: {exc}"[:500],
                "stdout_tail": buf.getvalue()[-300:]}


r = {"cell3": run_cell(3), "cell5": run_cell(5)}
t0 = time.time()
ns["snapshot"] = ns["verify_snapshot"](WEIGHTS)
ns["pipe"] = ns["OwlViTDetectionPipeline"].from_pretrained(weights_dir=WEIGHTS, device="cpu")
r["load_s"] = round(time.time() - t0, 1)
r["snapshot"] = ns["snapshot"]
r["pipe_has_source_attr"] = hasattr(ns["pipe"], "source")
for i in (9, 11, 13, 15, 17):
    r[f"cell{i}"] = run_cell(i)
r["default_detections"] = ns["result"]["detections"]
r["default_report_metrics"] = ns["report"]["metrics"]
r["outputs"] = sorted(os.listdir("outputs"))
results["P2_default"] = r
save()

# P3: active learning — threshold sweep, prompt phrasing, absent object; per-query max score at threshold 0
pipe, image, drawn = ns["pipe"], ns["image"], ns["drawn_boxes"]
box_iou = ns["box_iou"]


def summary(prompts, thr):
    res = pipe.detect(image, prompts, threshold=thr)
    dets = res["detections"]
    per = {}
    for q in res["queries"]:
        mine = [d for d in dets if d["label"] == q]
        per[q] = {"n": len(mine), "max_score": round(max((d["score"] for d in mine), default=0.0), 4)}
    return {"n": len(dets), "per_query": per}


a = {}
for thr in (0.1, 0.05, 0.02):
    a[f"plain_thr{thr}"] = summary(list(drawn), thr)
photo = {f"a photo of {k[2:]}" if k.startswith("a ") else k: v for k, v in drawn.items()}
photo = {"a photo of a black rectangle": drawn["a black rectangle"], "a photo of a red circle": drawn["a red circle"],
         "a photo of a blue triangle": drawn["a blue triangle"]}
for thr in (0.1, 0.05):
    a[f"photo_thr{thr}"] = summary(list(photo), thr)
a["absent_green_star_thr0.1"] = summary([*drawn, "a green star"], 0.1)
# threshold 0: every patch's best query; best-IoU box per reference and its score/label
res0 = pipe.detect(image, list(drawn), threshold=0.0)
best = {}
for q, ref in drawn.items():
    mine = [d for d in res0["detections"] if d["label"] == q]
    top = max(mine, key=lambda d: d["score"]) if mine else None
    bi = max(res0["detections"], key=lambda d: box_iou(d["box"], ref))
    best[q] = {"n_patches_labelled": len(mine), "top_score": round(top["score"], 4) if top else None,
               "top_score_box_iou": round(box_iou(top["box"], ref), 4) if top else None,
               "best_iou_box": {"iou": round(box_iou(bi["box"], ref), 4), "label": bi["label"], "score": round(bi["score"], 4)}}
a["thr0_per_reference"] = best
a["thr0_n"] = len(res0["detections"])
# Notebook's own rerun path: change the threshold form value and rerun cells 9..17
rr = {}
for i in (9, 11, 13, 15, 17):
    rr[f"cell{i}"] = run_cell(i, {"threshold": 0.05} if i == 9 else None)
rr["n_detections"] = len(ns["result"]["detections"])
rr["report_threshold"] = ns["report"]["threshold"]
rr["csv_rows"] = sum(1 for _ in open("outputs/owlvit_detection_detections.csv", encoding="utf-8")) - 1
a["rerun_from_cell9_thr0.05"] = rr
# Max-length prompt within MAX_PROMPT_CHARS: does the 16-token truncation happen silently?
long_phrase = "1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4"[:48]
tok = None
try:
    from transformers import OwlViTProcessor
    proc = OwlViTProcessor.from_pretrained(str(WEIGHTS), local_files_only=True)
    tok = len(proc.tokenizer(long_phrase)["input_ids"])
    out = pipe.detect(image, [long_phrase], threshold=0.1)
    a["long_prompt"] = {"chars": len(long_phrase), "clip_tokens_incl_bos_eos": tok, "detect_ok": True,
                        "n": len(out["detections"])}
except Exception as exc:  # noqa: BLE001
    a["long_prompt"] = {"chars": len(long_phrase), "clip_tokens_incl_bos_eos": tok, "detect_ok": False,
                        "error": f"{type(exc).__name__}: {exc}"[:400]}
results["P3_active"] = a
save()

# P4: reuse and recovery — BYOD via the location field (stand-in images), invalid inputs
from PIL import Image  # noqa: E402

b = {}
stand = work / "byod_rgba.png"
im = Image.new("RGBA", (800, 600), (200, 200, 200, 255))
from PIL import ImageDraw  # noqa: E402

ImageDraw.Draw(im).ellipse([100, 100, 300, 300], fill=(220, 30, 30, 255))
im.save(stand)


def byod(path, prompts, upto=17):
    out = {}
    for i in (9, 11, 13, 15, 17):
        if i > upto:
            break
        ov = {"USE_BYOD": True, "BYOD_IMAGE_PATH": str(path), "BYOD_PROMPTS": prompts} if i == 9 else None
        out[f"cell{i}"] = run_cell(i, ov)
        if not out[f"cell{i}"]["ok"]:
            break
    return out


b["stand_in_rgba_png"] = byod(stand, "a red circle, a photo of a cat")
b["stand_in_verdict"] = ns.get("report", {}).get("verdict")
b["stand_in_sample_kind"] = json.load(open("outputs/owlvit_detection_result.json", encoding="utf-8"))["sample"]["kind"]
b["seventeen_phrases"] = byod(stand, ", ".join(f"thing {k}" for k in range(17)), upto=11)
b["empty_prompts"] = byod(stand, " , ", upto=11)
b["duplicate_prompts"] = byod(stand, "a cat, A cat.", upto=11)
b["missing_path"] = byod(work / "nope.jpg", "a cat", upto=9)
txt = work / "not_image.jpg"
txt.write_text("hello", encoding="utf-8")
b["non_image_file"] = byod(txt, "a cat", upto=9)
tiny = work / "tiny.png"
Image.new("RGB", (10, 10)).save(tiny)
b["tiny_image"] = byod(tiny, "a cat", upto=11)
# Empty location field outside Colab -> google.colab upload branch
b["empty_path_outside_colab"] = run_cell(9, {"USE_BYOD": True, "BYOD_IMAGE_PATH": ""})
# Stale state: after a failed BYOD validation, were the previous outputs left in place?
b["outputs_after_failures"] = sorted(os.listdir("outputs"))
results["P4_reuse"] = b
results["env"] = {"python": sys.version.split()[0], "torch": torch.__version__,
                  "transformers": __import__("transformers").__version__, "pillow": Image.__version__,
                  "numpy": __import__("numpy").__version__, "threads": torch.get_num_threads(),
                  "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES"), "workdir": str(work)}
save()
print("done", OUT)

# P5: realistic BYOD phrases within MAX_PROMPT_CHARS but over the 16-token CLIP limit
p5 = {}
from transformers import OwlViTProcessor  # noqa: E402

_proc = OwlViTProcessor.from_pretrained(str(WEIGHTS), local_files_only=True)
for phrases in (["a photo of a red-and-white 330-ml soda can"],
                ["a photo of a carabao (bubalus bubalis) calf", "a photo of a dog"],
                ["a photo of a philippine eagle (pithecophaga)"]):
    key = " | ".join(phrases)
    entry = {"chars": [len(x) for x in phrases], "clip_tokens": [len(_proc.tokenizer(x.lower())["input_ids"]) for x in phrases]}
    entry["validate_inputs"] = ns["validate_inputs"](image, phrases)["verdict"]
    try:
        out = pipe.detect(image, phrases, threshold=0.1)
        entry["detect"] = f"ok, {len(out['detections'])} detections"
    except Exception as exc:  # noqa: BLE001
        entry["detect"] = f"{type(exc).__name__}: {exc}"[:200]
    p5[key] = entry
results["P5_token_limit"] = p5
save()
print("done P5")
